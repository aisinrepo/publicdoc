const videoContainer = document.querySelectorAll(".video-image");
//const video = document.getElementsByClassName(".video");
let originalTime
Array.from(videoContainer).forEach(container => {
  const videoElement = container.querySelector('.video');
  container.addEventListener("mouseover", () => {
    videoElement.currentTime = 0
    videoElement.play();
   
  });

  container.addEventListener("mouseleave", () => {
    videoElement.pause();
    videoElement.currentTime = 0
    
  });
  
});